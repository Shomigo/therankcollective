# Design Guidelines - AEO Platform

## Design Philosophy
Dark, tech-forward SaaS platform aesthetic inspired by modern data platforms like Profound. Clean, minimal, and sophisticated with a focus on data visualization and professional credibility.

## Color Palette

### Dark Mode (Default)
- **Background**: Near-black (#0a0a0a / hsl(0 0% 4%)) - deep, rich black
- **Surface/Card**: Subtle elevation (#18181b / hsl(0 0% 10%)) - slightly lighter than background
- **Primary Accent**: Vibrant blue (#3b82f6 / hsl(217 91% 60%)) - tech-forward, trustworthy
- **Text Primary**: Pure white (#ffffff / hsl(0 0% 100%)) - maximum contrast
- **Text Secondary**: Soft gray (#a1a1aa / hsl(0 0% 65%)) - readable but subdued
- **Borders**: Subtle dark borders (#27272a / hsl(0 0% 15%)) - barely visible separation

## Typography
- **Headings**: Inter (weight: 700-900) - bold, technical, modern
- **Body**: Inter (weight: 400-500) - clean and readable
- **Mono/Data**: JetBrains Mono - for statistics, metrics, code-like elements
- **Scale**: More restrained - tech platforms use tighter typography

## Spacing & Layout
- **Tighter spacing**: Professional SaaS platforms use less whitespace
- **Grid-based**: Consistent, mathematical spacing
- **Card-based layouts**: Information grouped in subtle cards with soft borders
- **Data-driven**: Emphasis on metrics, dashboards, and analytics

## Visual Style
- **Minimal gradients**: Subtle, barely-there gradients on backgrounds only
- **No decorative elements**: Pure function, no ornamental design
- **Data visualization**: Charts, metrics, and numbers take center stage
- **Soft shadows**: Barely visible elevation
- **Border radius**: Small, consistent (8px max) - professional

## Components
- **Buttons**: Solid fills with subtle hover states
- **Cards**: Dark backgrounds with subtle borders, soft shadows
- **Forms**: Clean inputs with focus states
- **Navigation**: Minimal, clean, sticky header with subtle backdrop blur
- **Stats/Metrics**: Large numbers in mono font, clear labels

## Overall Vibe
- Enterprise SaaS platform, not creative agency
- Data-driven and analytical
- Clean, professional, trustworthy
- Tech-forward and modern
- Sophisticated without being flashy
