import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/hero-section";
import { StatsBar } from "@/components/stats-bar";
import { ProblemSection } from "@/components/problem-section";
import { AEOExplanation } from "@/components/aeo-explanation";
import { HowWeWorkSection } from "@/components/how-we-work-section";
import { PlatformSection } from "@/components/platform-section";
import { ResultsSection } from "@/components/results-section";
import { ContactSection } from "@/components/contact-section";
import { FAQSection } from "@/components/faq-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <HeroSection />
        <StatsBar />
        <ProblemSection />
        <AEOExplanation />
        <HowWeWorkSection />
        <PlatformSection />
        <ResultsSection />
        <ContactSection />
        <FAQSection />
      </main>
      <Footer />
    </div>
  );
}
