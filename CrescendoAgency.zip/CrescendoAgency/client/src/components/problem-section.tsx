import { FadeInSection } from "./fade-in-section";
import { motion } from "framer-motion";

const insights = [
  {
    title: "Search is dead",
    description: "People ask AI. They trust the first answer. If you're not in it, you're invisible.",
  },
  {
    title: "AI is winning",
    description: "ChatGPT beats Bing. It's catching TikTok. This isn't the future—it's now.",
  },
  {
    title: "Brands don't see it",
    description: "They chase SEO keywords while AI hands their customers to competitors.",
  },
  {
    title: "Stakes are higher",
    description: "Page 1 on Google matters. But AI mentioning your competitor first? Game over.",
  },
];

export function ProblemSection() {
  return (
    <section className="py-32 md:py-40 px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <FadeInSection>
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em]">
              The truth about AI search
            </h2>
          </div>
        </FadeInSection>

        <div className="grid md:grid-cols-2 gap-px bg-white/[0.05] rounded-sm">
          {insights.map((insight, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group relative p-16 bg-black hover:bg-white/[0.01] transition-all duration-500"
              data-testid={`insight-${index}`}
            >
              {/* Hover gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative space-y-4">
                <h3 className="text-2xl font-bold tracking-tight">
                  {insight.title}
                </h3>
                <p className="text-white/50 leading-relaxed text-lg">
                  {insight.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}