import { FadeInSection } from "./fade-in-section";
import dashboardImage from "@assets/generated_images/AEO_analytics_dashboard_interface_cae7f839.png";

const features = [
  "Track mentions across ChatGPT, Claude, Perplexity",
  "Monitor competitor visibility in real-time", 
  "Identify high-value prompts and queries",
  "Measure AI-driven traffic and conversions",
];

export function PlatformSection() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  };

  return (
    <section id="platform" className="py-20 md:py-28 px-6 lg:px-8 border-t border-white/5">
      <div className="max-w-6xl mx-auto">
        <FadeInSection>
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tighter">
              The platform
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Real-time visibility into your AI presence
            </p>
          </div>
        </FadeInSection>

        <FadeInSection delay={0.2}>
          <div className="mb-12 relative rounded-lg overflow-hidden border border-white/10">
            <img
              src={dashboardImage}
              alt="AEO Analytics Dashboard"
              className="w-full h-auto opacity-80"
              loading="lazy"
              data-testid="img-dashboard"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
          </div>
        </FadeInSection>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {features.map((feature, index) => (
            <FadeInSection key={index} delay={0.3 + index * 0.1}>
              <div className="flex items-start gap-4" data-testid={`platform-feature-${index}`}>
                <div className="w-px h-8 bg-white/30 mt-1" />
                <p className="text-lg text-muted-foreground">
                  {feature}
                </p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </div>
    </section>
  );
}