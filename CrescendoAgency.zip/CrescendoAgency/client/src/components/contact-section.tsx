import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export function ContactSection() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      message: "",
    },
  });

  const mutation = useMutation({
    mutationFn: (data: InsertContact) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      setIsSubmitted(true);
      form.reset();
      toast({
        title: "Request received",
        description: "We'll contact you within 24 hours.",
      });
      setTimeout(() => setIsSubmitted(false), 5000);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to submit. Please try again.",
      });
    },
  });

  const onSubmit = (data: InsertContact) => mutation.mutate(data);

  return (
    <section id="contact" className="relative py-32 md:py-40 px-6 lg:px-8">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em] mb-6">
            Start your audit
          </h2>
          <p className="text-xl text-white/50 font-light">
            48-hour turnaround. No commitment.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="bg-black border border-white/10 p-12 md:p-16">
            {isSubmitted ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <CheckCircle2 className="w-20 h-20 text-primary mb-8" />
                <h3 className="text-3xl font-bold mb-4">Received</h3>
                <p className="text-white/50 text-lg">
                  Check your email within 24 hours.
                </p>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                  <div className="grid md:grid-cols-2 gap-8">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white/60 text-xs uppercase tracking-wider">Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="John Smith"
                              {...field}
                              disabled={mutation.isPending}
                              className="bg-transparent border-white/20 rounded-none h-12 text-white placeholder:text-white/30 focus:border-primary/50 transition-colors"
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white/60 text-xs uppercase tracking-wider">Email</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="john@company.com"
                              {...field}
                              disabled={mutation.isPending}
                              className="bg-transparent border-white/20 rounded-none h-12 text-white placeholder:text-white/30 focus:border-primary/50 transition-colors"
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white/60 text-xs uppercase tracking-wider">Company</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Company Name"
                            {...field}
                            disabled={mutation.isPending}
                            className="bg-transparent border-white/20 rounded-none h-12 text-white placeholder:text-white/30 focus:border-primary/50 transition-colors"
                            data-testid="input-company"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white/60 text-xs uppercase tracking-wider">Current Challenge</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="What's your biggest concern about AI visibility?"
                            className="min-h-32 resize-none bg-transparent border-white/20 rounded-none text-white placeholder:text-white/30 focus:border-primary/50 transition-colors"
                            {...field}
                            disabled={mutation.isPending}
                            data-testid="input-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full text-sm py-4 rounded-none bg-white text-black hover:bg-white/90 font-medium tracking-wide transition-all duration-300"
                    disabled={mutation.isPending}
                    data-testid="button-submit"
                  >
                    {mutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      "Get Your Free Audit"
                    )}
                  </Button>
                </form>
              </Form>
            )}
          </div>
          
          {/* Subtle glow */}
          <div className="absolute -inset-1 bg-gradient-to-r from-primary/[0.05] via-primary/[0.1] to-primary/[0.05] blur-2xl opacity-30" />
        </motion.div>
      </div>
    </section>
  );
}