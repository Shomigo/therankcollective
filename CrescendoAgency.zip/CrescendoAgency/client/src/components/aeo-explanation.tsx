import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function AEOExplanation() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  };

  return (
    <section id="what-is-aeo" className="py-32 md:py-40 px-6 lg:px-8">
      <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-10"
          >
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em] leading-[0.9]">
              Answer Engine
              <br />
              <span className="text-white/30">Optimization</span>
            </h2>
            
            <div className="space-y-6 text-lg text-white/60 leading-relaxed">
              <p className="text-2xl text-white font-light tracking-[-0.02em]">
                AI doesn't show 10 links.
                <br />
                It gives one answer.
              </p>
              
              <p>
                When someone asks ChatGPT about your industry, does it mention you? Or your competitor?
              </p>
              
              <p>
                That split-second decision determines who gets the lead. And who gets forgotten.
              </p>
              
              <p className="text-2xl text-white font-light tracking-[-0.02em] pt-6">
                We make sure it's you.
              </p>
            </div>

            <Button
              size="lg"
              onClick={scrollToContact}
              className="text-sm px-8 py-3 rounded-none bg-white text-black hover:bg-white/90 font-medium tracking-wide transition-all duration-300"
              data-testid="button-aeo-cta"
            >
              Claim Your Position
            </Button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-black border border-white/10 p-10">
              <div className="space-y-6 font-mono text-sm">
                <div className="text-white/30 text-xs uppercase tracking-wider">User Query</div>
                <div className="pl-4 text-white/60 text-base">
                  "What's the best platform for enterprise data analytics?"
                </div>
                
                <div className="text-white/30 text-xs uppercase tracking-wider pt-4">AI Response</div>
                <div className="pl-4">
                  <p className="mb-6 text-white/80">For enterprise data analytics, I recommend:</p>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <span className="text-white/40 font-mono">1.</span>
                      <div>
                        <span className="text-white font-semibold text-lg">[Your Brand Here]</span>
                        <p className="text-white/50 text-sm mt-2">
                          Industry-leading platform trusted by Fortune 500 companies for real-time data processing and advanced analytics...
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Subtle glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-white/5 via-white/10 to-white/5 blur-xl opacity-50" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}