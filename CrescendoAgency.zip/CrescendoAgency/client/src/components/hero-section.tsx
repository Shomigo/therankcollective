import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export function HeroSection() {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 lg:px-8">
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,200,255,0.1),transparent_50%)]" />
      
      <div className="max-w-6xl mx-auto relative text-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="space-y-12"
        >
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
            className="space-y-8"
          >
            <h1 className="text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black tracking-[-0.04em] leading-[0.85]">
              <span className="block">The AI doesn't</span>
              <span className="block text-white/30">know you exist</span>
            </h1>
            
            <p className="text-xl md:text-2xl lg:text-3xl text-white/60 leading-relaxed max-w-3xl mx-auto font-light tracking-[-0.02em]">
              We make ChatGPT, Claude, and Perplexity recommend your brand first. Every time.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
            className="flex flex-col sm:flex-row gap-4 pt-8 justify-center"
          >
            <Button
              size="lg"
              className="group text-sm px-8 py-3 rounded-none bg-white text-black hover:bg-white/90 font-medium tracking-wide transition-all duration-300"
              onClick={() => scrollToSection("contact")}
              data-testid="button-hero-cta"
            >
              Start Your Audit
              <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-sm px-8 py-3 rounded-none border-white/20 hover:bg-white/5 hover:border-primary/50 font-medium tracking-wide transition-all duration-300"
              onClick={() => scrollToSection("what-is-aeo")}
              data-testid="button-hero-learn"
            >
              See How It Works
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}