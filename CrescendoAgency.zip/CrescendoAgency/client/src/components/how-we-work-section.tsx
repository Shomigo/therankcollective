import { motion } from "framer-motion";

const steps = [
  {
    number: "01",
    title: "Audit",
    description: "We analyze how AI sees you now. Every platform. Every prompt. Every mention.",
  },
  {
    number: "02",
    title: "Architect",
    description: "We restructure your content for AI comprehension. Entity relationships. Schema. Context.",
  },
  {
    number: "03",
    title: "Amplify",
    description: "We build authority signals that echo through training data. Mentions that matter.",
  },
  {
    number: "04",
    title: "Monitor",
    description: "We track your position across all AI platforms. Real-time. Always optimizing.",
  },
];

export function HowWeWorkSection() {
  return (
    <section id="services" className="py-32 md:py-40 px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em]">
            The process
          </h2>
        </motion.div>

        <div className="space-y-0">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="group relative"
              data-testid={`service-${index}`}
            >
              <div className="relative flex items-center gap-12 md:gap-20 py-12 md:py-16 hover:bg-white/[0.01] transition-all duration-500">
                {/* Number with line */}
                <div className="relative">
                  <div className="text-8xl md:text-9xl font-black text-white/20 tracking-[-0.04em]">
                    {step.number}
                  </div>
                  {index < steps.length - 1 && (
                    <div className="absolute left-1/2 -translate-x-1/2 top-full w-px h-24 md:h-32 bg-gradient-to-b from-white/10 to-transparent" />
                  )}
                </div>
                
                {/* Content */}
                <div className="flex-1 space-y-3">
                  <h3 className="text-3xl md:text-4xl font-bold tracking-tight group-hover:text-primary transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-white/50 text-lg md:text-xl leading-relaxed max-w-2xl">
                    {step.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}