import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  };

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${
      scrolled ? "bg-black/80 backdrop-blur-2xl border-b border-white/10" : "bg-transparent"
    }`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-12">
            <a href="/" className="text-2xl font-black tracking-[-0.04em] hover:text-primary transition-colors duration-300" data-testid="logo">
              THE RANK COLLECTIVE
            </a>
            
            <div className="hidden md:flex items-center gap-10">
              <button 
                onClick={() => scrollToSection("services")}
                className="text-sm font-light text-white/60 hover:text-white transition-colors duration-300 tracking-wide"
                data-testid="nav-services"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection("platform")}
                className="text-sm font-light text-white/60 hover:text-white transition-colors duration-300 tracking-wide"
                data-testid="nav-platform"
              >
                Platform
              </button>
              <button 
                onClick={() => scrollToSection("results")}
                className="text-sm font-light text-white/60 hover:text-white transition-colors duration-300 tracking-wide"
                data-testid="nav-results"
              >
                Results
              </button>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <Button 
              variant="outline"
              onClick={() => scrollToSection("contact")}
              className="hidden md:inline-flex rounded-none px-6 py-2.5 border-white/20 hover:bg-primary hover:text-black hover:border-primary transition-all duration-300 font-light tracking-wide text-sm"
              data-testid="nav-cta"
            >
              Get Started
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="mobile-menu-toggle"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 right-0 bg-black/95 backdrop-blur-2xl border-b border-white/10">
          <div className="px-6 py-6 space-y-4">
            <button 
              onClick={() => scrollToSection("services")}
              className="block w-full text-left text-sm font-light text-white/60 hover:text-white transition-colors"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection("platform")}
              className="block w-full text-left text-sm font-light text-white/60 hover:text-white transition-colors"
            >
              Platform
            </button>
            <button 
              onClick={() => scrollToSection("results")}
              className="block w-full text-left text-sm font-light text-white/60 hover:text-white transition-colors"
            >
              Results
            </button>
            <Button 
              variant="outline"
              onClick={() => scrollToSection("contact")}
              className="w-full mt-4 rounded-none border-white/20"
            >
              Get Started
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}