import { AnimatedCounter } from "./animated-counter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const metrics = [
  { value: "+247", suffix: "%", label: "AI Visibility" },
  { value: "12", suffix: "x", label: "Brand Mentions" },
  { value: "+83", suffix: "%", label: "Qualified Leads" },
  { value: "+31", suffix: "%", label: "Revenue Growth" },
];

export function ResultsSection() {
  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ 
      behavior: "smooth", 
      block: "start" 
    });
  };

  return (
    <section id="results" className="py-32 md:py-40 px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em]">
            Results that matter
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 mb-24">
          {metrics.map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="text-center"
              data-testid={`metric-${index}`}
            >
              <div className="text-6xl md:text-7xl font-black tracking-[-0.04em] mb-4 bg-gradient-to-b from-primary via-primary/60 to-white/40 bg-clip-text text-transparent">
                <AnimatedCounter value={`${metric.value}${metric.suffix}`} duration={2500} />
              </div>
              <p className="text-xs uppercase tracking-[0.2em] text-white/40 font-medium">
                {metric.label}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="relative"
        >
          <div className="bg-black border border-white/10 p-16 md:p-20">
            <div className="max-w-3xl">
              <p className="text-xs uppercase tracking-[0.3em] text-primary/60 mb-8 font-medium">
                Case Study
              </p>
              
              <h3 className="text-4xl md:text-5xl font-black tracking-[-0.04em] mb-12">
                SaaS Platform • Enterprise
              </h3>
              
              <div className="space-y-8 text-white/60 text-lg leading-relaxed">
                <p>
                  Market leader by revenue. Invisible to AI. Zero presence in ChatGPT, Claude, or Perplexity responses. 
                  Smaller competitors mentioned first in every query.
                </p>
                
                <p>
                  Six-month transformation. Complete content restructure. Built semantic authority. 
                  Optimized for AI training patterns.
                </p>
                
                <p className="text-white text-xl font-light pt-4">
                  Now the default AI recommendation for enterprise solutions. 
                  <span className="text-primary"> 83% increase</span> in qualified pipeline. 
                  <span className="text-primary"> 31% revenue growth</span> directly attributed to AI referrals.
                </p>
              </div>
            </div>
          </div>
          
          {/* Corner accent */}
          <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-primary/40" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-b-2 border-r-2 border-primary/40" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="text-center mt-16"
        >
          <Button
            size="lg"
            onClick={scrollToContact}
            className="text-sm px-8 py-3 rounded-none bg-primary text-black hover:bg-primary/90 font-medium tracking-wide transition-all duration-300"
            data-testid="button-results-cta"
          >
            Get Similar Results
          </Button>
        </motion.div>
      </div>
    </section>
  );
}