import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Is this just SEO with a new name?",
    answer: "No. SEO optimizes for search engines. AEO optimizes for AI platforms. Different algorithms, different approach, different results.",
  },
  {
    question: "How quickly can we see results?",
    answer: "Initial improvements in 2-3 months. Significant momentum by month 6. The key is that once established, your authority compounds over time.",
  },
  {
    question: "Will this help with traditional SEO too?",
    answer: "Yes. The entity architecture and authority signals that boost AI visibility also strengthen traditional SEO. You win on both fronts.",
  },
  {
    question: "What kind of companies need this?",
    answer: "Any business where buyers research before purchasing. B2B SaaS, professional services, healthcare, finance. If customers ask AI about your industry, you need AEO.",
  },
  {
    question: "How do you measure success?",
    answer: "Brand mentions across AI platforms. Prompt coverage. Competitive position. And most importantly: AI-driven leads and revenue.",
  },
  {
    question: "Do we need new content?",
    answer: "Sometimes. We often start by restructuring existing content for AI comprehension. New content fills gaps and targets specific prompts.",
  },
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 md:py-28 px-6 lg:px-8 border-t border-white/5">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tighter">
            Questions
          </h2>
        </div>

        <Accordion type="single" collapsible className="space-y-2">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="border border-white/10 rounded-lg px-6 hover:border-white/20 transition-colors"
              data-testid={`faq-item-${index}`}
            >
              <AccordionTrigger className="text-left hover:no-underline py-5">
                <span className="text-base font-medium pr-6">
                  {faq.question}
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-5">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}