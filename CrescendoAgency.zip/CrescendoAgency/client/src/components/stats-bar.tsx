import { AnimatedCounter } from "./animated-counter";
import { motion } from "framer-motion";

const stats = [
  { value: "42", suffix: "%", label: "of searches start with AI" },
  { value: "3", suffix: "x", label: "higher conversion rate" },
  { value: "89", suffix: "%", label: "trust AI recommendations" },
  { value: "2025", label: "is the year of AI search" },
];

export function StatsBar() {
  return (
    <section className="relative py-24 md:py-32 px-6 lg:px-8">
      {/* Subtle lines */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      </div>
      
      <div className="max-w-7xl mx-auto relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="text-center group"
              data-testid={`stat-${index}`}
            >
              <div className="text-5xl md:text-6xl lg:text-7xl font-black tracking-[-0.04em] mb-4 bg-gradient-to-b from-white via-white/80 to-primary/60 bg-clip-text text-transparent">
                <AnimatedCounter value={`${stat.value}${stat.suffix || ''}`} duration={2000} />
              </div>
              <p className="text-xs md:text-sm text-white/40 font-medium uppercase tracking-[0.2em]">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}