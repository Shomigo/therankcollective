# The Rank Collective - Answer Engine Optimization Agency

## Overview

This is a marketing landing page for an Answer Engine Optimization (AEO) agency called "The Rank Collective". The application helps businesses optimize their digital presence to be recommended by AI platforms like ChatGPT, Claude, Perplexity, and Gemini. The site showcases the agency's services, results, and provides a contact form for lead generation.

The application is built as a modern single-page application with a React frontend and Express backend, designed for high performance and premium aesthetics with a sophisticated dark-only design featuring black backgrounds, white typography, and strategic electric blue accents.

## User Preferences

- Preferred communication style: Simple, everyday language
- Design preference: Premium, dark-only aesthetic with no light mode toggle
- Branding: Agency name is "The Rank Collective" (therankcollective.com)

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type safety and modern component architecture
- Vite as the build tool for fast development and optimized production builds
- Wouter for lightweight client-side routing (single route to Home page)
- Single-page application pattern with all content on the home page

**UI Component System**
- Shadcn/ui component library (New York style variant) for consistent, accessible UI components
- Radix UI primitives as the foundation for interactive components
- Tailwind CSS for utility-first styling with custom design tokens
- Dark-only theme system via ThemeProvider context (no light mode)

**Design System**
- Typography: Inter for headings/UI, system-ui fallback for body, JetBrains Mono for statistics
- Spacing system based on Tailwind's 4px grid (units: 4, 6, 8, 12, 16, 20, 24, 32)
- Responsive containers with max-widths: 7xl (full sections), 6xl (content), 4xl (text-focused)
- Premium aesthetic with generous whitespace, spacious layouts, and technology-forward design
- Custom CSS variables for colors, borders, and elevation effects
- Color scheme: Pure black background, white text, electric blue accents (#00c8ff)
- Sharp corners throughout (rounded-none) for modern, minimal aesthetic

**State Management & Data Fetching**
- TanStack React Query (v5) for server state management and API communication
- React Hook Form with Zod validation for form handling (contact form)
- Local context providers for theme management

**Animation & Interactions**
- Framer Motion for page transitions and scroll-triggered animations
- Intersection Observer API for scroll-based reveal effects (FadeInSection component)
- Custom AnimatedCounter component for statistics with visibility-triggered animations

**Key Page Sections (in order)**
1. Navigation - Sticky header with smooth scroll to sections (featuring "THE RANK COLLECTIVE" branding)
2. Hero Section - Large hero with CTA and visual mockup
3. Stats Bar - Animated statistics showcasing results
4. Problem Section - Cards explaining market shift to AI search
5. AEO Explanation - What is AEO and why it matters
6. How We Work Section - 4-step process cards
7. Platform Section - Proprietary tool features with dashboard mockup
8. Results Section - Case study with metrics
9. Contact Section - Lead generation form with validation
10. FAQ Section - Accordion-style frequently asked questions
11. Footer - Links and company information with "THE RANK COLLECTIVE" branding

### Backend Architecture

**Server Framework**
- Express.js as the web server framework
- Node.js with ESM module system
- TypeScript for type safety across client and server

**API Design**
- RESTful API endpoints under `/api` prefix
- `/api/contact` - POST endpoint for contact form submissions
- `/api/contact/submissions` - GET endpoint for retrieving all submissions
- JSON request/response format with structured error handling
- Zod schema validation for request data using shared schemas

**Development Server**
- Vite middleware integration for HMR (Hot Module Replacement) in development
- Custom logging middleware for API request/response tracking
- Error handling with proper HTTP status codes (400 for validation, 500 for server errors)

**Data Layer**
- In-memory storage implementation (MemStorage class) for development/demo
- Storage interface (IStorage) designed for easy swapping to database implementation
- Separation of concerns: storage logic abstracted from route handlers

**Database Schema Design** (Drizzle ORM)
- PostgreSQL dialect configured via Drizzle
- Two main tables defined in shared schema:
  - `users` - Basic user authentication (id, username, password)
  - `contact_submissions` - Lead capture (id, name, email, company, message, createdAt)
- UUID primary keys using `gen_random_uuid()`
- Timestamps with default values
- Schema validation using drizzle-zod for runtime type checking

**Shared Code Architecture**
- `/shared` directory for code used by both client and server
- Zod schemas for validation and TypeScript type inference
- Type exports for InsertUser, User, InsertContact, ContactSubmission

### External Dependencies

**Database & ORM**
- Drizzle ORM for type-safe database queries and schema management
- @neondatabase/serverless for PostgreSQL connection (Neon database provider)
- Drizzle Kit for schema migrations (configured in drizzle.config.ts)
- Environment variable `DATABASE_URL` required for database connection

**UI Component Libraries**
- @radix-ui/* - Comprehensive suite of 20+ accessible UI primitives
- embla-carousel-react - Touch-enabled carousel component
- cmdk - Command menu component
- lucide-react - Icon library
- class-variance-authority - Type-safe variant styling
- tailwind-merge + clsx - CSS class merging utilities

**Form & Validation**
- react-hook-form - Form state management
- @hookform/resolvers - Integration between react-hook-form and Zod
- zod - Schema validation library
- zod-validation-error - Human-readable Zod error messages
- drizzle-zod - Zod schema generation from Drizzle schemas

**Animation & Motion**
- framer-motion - Animation library for React

**Date Utilities**
- date-fns - Modern date utility library

**Build Tools**
- TypeScript compiler for type checking
- esbuild - Fast bundler for production server build
- PostCSS with Tailwind CSS and Autoprefixer

**Development Tools**
- @replit/vite-plugin-runtime-error-modal - Error overlay for Replit
- @replit/vite-plugin-cartographer - Replit code mapping
- @replit/vite-plugin-dev-banner - Development banner
- tsx - TypeScript execution for development server

**Assets**
- Static images stored in `attached_assets/generated_images/` directory
- Images imported directly into components via Vite aliases
- Three key images: AI search mockup, analytics dashboard, law firm building

**Environment Configuration**
- Development mode: NODE_ENV=development with Vite dev server
- Production mode: NODE_ENV=production with pre-built static files
- Database URL must be provided via environment variable
- Optional Replit-specific plugins activated when REPL_ID is present